const Images = {
  Masjid: require('../Assets/masjid.jpg'),
  logo: require('../Assets/logo.png')
}
export default Images;