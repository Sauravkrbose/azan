const RandomImages = [
  ('https://images.unsplash.com/photo-1519817650390-64a93db51149?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=327&q=80'),
  ('https://images.unsplash.com/photo-1519818187420-8e49de7adeef?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=327&q=80'),
  ('https://images.unsplash.com/photo-1590273089302-ebbc53986b6e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NXx8bW9zcXVlfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60'),
  ('https://images.unsplash.com/photo-1572358899655-f63ece97bfa5?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8OXx8bW9zcXVlfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60'),
  ('https://images.unsplash.com/photo-1577561426384-62154a1e9457?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTF8fG1vc3F1ZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60'),
  ('https://images.unsplash.com/photo-1564407727371-3eece6c58961?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTR8fG1vc3F1ZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60'),
  ('https://images.unsplash.com/photo-1513072064285-240f87fa81e8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1yZWxhdGVkfDE4fHx8ZW58MHx8fHw%3D&auto=format&fit=crop&w=500&q=60'),
  ('https://images.unsplash.com/photo-1605976528013-638e49b6599f?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxjb2xsZWN0aW9uLXBhZ2V8MXw5NTE1MzYwfHxlbnwwfHx8fA%3D%3D&auto=format&fit=crop&w=500&q=60'),
  ('https://images.unsplash.com/photo-1602733458155-647c07d32ef6?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxjb2xsZWN0aW9uLXBhZ2V8N3w5NTE1MzYwfHxlbnwwfHx8fA%3D%3D&auto=format&fit=crop&w=500&q=60'),
  ('https://images.unsplash.com/photo-1602769490455-36cf9734dbcb?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxjb2xsZWN0aW9uLXBhZ2V8OHw5NTE1MzYwfHxlbnwwfHx8fA%3D%3D&auto=format&fit=crop&w=500&q=60'),
  ('https://images.unsplash.com/photo-1589034692352-15dbd252b6bf?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxjb2xsZWN0aW9uLXBhZ2V8MTB8OTUxNTM2MHx8ZW58MHx8fHw%3D&auto=format&fit=crop&w=500&q=60'),
  ('https://images.unsplash.com/photo-1574146867315-e131b71130b6?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxjb2xsZWN0aW9uLXBhZ2V8MTR8OTUxNTM2MHx8ZW58MHx8fHw%3D&auto=format&fit=crop&w=500&q=60'),
  ('https://images.unsplash.com/photo-1578109002083-e2e8691c4f85?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxjb2xsZWN0aW9uLXBhZ2V8MTV8OTUxNTM2MHx8ZW58MHx8fHw%3D&auto=format&fit=crop&w=500&q=60'),
  ('https://images.unsplash.com/photo-1584186028062-637e3e77318d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxjb2xsZWN0aW9uLXBhZ2V8M3xWSWdpbkh3QnpURXx8ZW58MHx8fHw%3D&auto=format&fit=crop&w=500&q=60'),
  ('https://thumbs.dreamstime.com/b/holy-islamic-book-koran-quran-closed-rosary-10847857.jpg'),
]
export default RandomImages;