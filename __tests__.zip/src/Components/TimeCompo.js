import React, {useState, useEffect} from 'react';
import {Text} from 'react-native';
import moment from 'moment';

import getStyle from '../Screens/Home/Styles';
const TimeCompo = () => {
  const {styles} = getStyle();
  const [state, setState] = useState('');
  const UpdateTime = () => {
    var time = moment().utcOffset('+05:00').format(' hh:mm:ss A');
    setState(time);
  };
  useEffect(() => {
    setInterval(() => {
      UpdateTime();
    }, 1000);
    return () => {
      clearInterval();
    };
  }, [state]);
  return <Text style={[styles.txtTime, {color: '#fff'}]}>{state}</Text>;
};

export default TimeCompo;
